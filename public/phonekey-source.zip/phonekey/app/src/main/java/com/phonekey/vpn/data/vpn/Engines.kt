package com.phonekey.vpn.data.vpn

import android.content.Context
import com.phonekey.vpn.data.parser.ConfigTexts
import com.phonekey.vpn.domain.engine.EngineOptions
import com.phonekey.vpn.domain.engine.TrafficSnapshot
import com.phonekey.vpn.domain.engine.VpnEngine
import com.phonekey.vpn.domain.model.Protocol
import com.phonekey.vpn.domain.model.VpnProfile
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.net.InetAddress

/**
 * A userspace blackhole can be held by [com.phonekey.vpn.service.PhoneKeyVpnService]
 * after a drop, but only while that process is alive. Android's Always-on VPN
 * plus "Block connections without VPN" is the block that survives process death.
 */
object KillSwitch {
    const val MAX_RECONNECTS = 3
}

class EndpointProbe {
    /** Returns the host when a public DNS lookup fails. Never contacts an ad or telemetry host. */
    fun unresolvedHost(configText: String): String? {
        val endpoint = ConfigTexts.endpointHost(configText) ?: return null
        val host = endpoint.substringBeforeLast(':').trim().removePrefix("[").removeSuffix("]")
        if (host.isEmpty() || host.any { it == ':' } || host.all { it.isDigit() || it == '.' }) return null
        return try {
            if (InetAddress.getAllByName(host).isEmpty()) host else null
        } catch (_: Exception) {
            host
        }
    }
}

private class NamedTunnel(
    private val name: String,
    private val onState: (Tunnel.State) -> Unit,
) : Tunnel {
    override fun getName(): String = name

    override fun onStateChange(newState: Tunnel.State) {
        onState(newState)
    }
}

class WireGuardEngine(
    context: Context,
    private val onTunnelDown: (String) -> Unit,
) : VpnEngine {
    override val protocol = Protocol.WIREGUARD
    private val backend by lazy { GoBackend(context.applicationContext) }

    @Volatile
    private var active: NamedTunnel? = null

    @Volatile
    private var activeProfileId: String? = null

    override suspend fun connect(profile: VpnProfile, options: EngineOptions) {
        withContext(Dispatchers.IO) {
            val text = ConfigTexts.withApplicationFilter(
                profile.rawConfig,
                options.packages,
                options.includeOnly,
            )
            val config = try {
                Config.parse(ByteArrayInputStream(text.toByteArray(Charsets.UTF_8)))
            } catch (error: Exception) {
                throw IllegalArgumentException(
                    "WireGuard rejected this config: ${error.message ?: "invalid .conf"}",
                    error,
                )
            }
            val tunnel = NamedTunnel(ConfigTexts.tunnelName(profile)) { state ->
                if (state == Tunnel.State.DOWN) {
                    activeProfileId?.let(onTunnelDown)
                }
            }
            active = tunnel
            activeProfileId = profile.id
            val result = backend.setState(tunnel, Tunnel.State.UP, config)
            if (result != Tunnel.State.UP) {
                throw IllegalStateException("WireGuard stayed down.")
            }
        }
    }

    override suspend fun disconnect() {
        val tunnel = active ?: return
        try {
            withContext(Dispatchers.IO) {
                backend.setState(tunnel, Tunnel.State.DOWN, null)
            }
        } finally {
            active = null
            activeProfileId = null
        }
    }

    override fun snapshot(): TrafficSnapshot? {
        val tunnel = active ?: return null
        return try {
            val stats = backend.getStatistics(tunnel)
            TrafficSnapshot(stats.totalRx(), stats.totalTx())
        } catch (_: Exception) {
            null
        }
    }
}

class XrayEngine : VpnEngine {
    override val protocol = Protocol.XRAY

    override suspend fun connect(profile: VpnProfile, options: EngineOptions) {
        throw IllegalStateException(
            "Xray is not implemented. PhoneKey connects with WireGuard only.",
        )
    }

    override suspend fun disconnect() = Unit

    override fun snapshot(): TrafficSnapshot? = null
}

class SstpEngine : VpnEngine {
    override val protocol = Protocol.SSTP

    override suspend fun connect(profile: VpnProfile, options: EngineOptions) {
        throw IllegalStateException(
            "SSTP is not implemented. PhoneKey connects with WireGuard only.",
        )
    }

    override suspend fun disconnect() = Unit

    override fun snapshot(): TrafficSnapshot? = null
}

class EngineFactory(
    context: Context,
    onTunnelDown: (String) -> Unit,
) {
    private val wireGuard by lazy { WireGuardEngine(context, onTunnelDown) }
    private val xray = XrayEngine()
    private val sstp = SstpEngine()

    fun forProtocol(protocol: Protocol): VpnEngine = when (protocol) {
        Protocol.WIREGUARD -> wireGuard
        Protocol.XRAY -> xray
        Protocol.SSTP -> sstp
    }
}
